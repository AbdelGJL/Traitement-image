import sys
import os
import datetime

class Employee:
    def __init__(self, pin):
        self.pin = pin

    def login_menu(self):
        print("Welcome to Abdelaksom !")
        print("1. Bank Employee")
        print("2. Customer")
        print("3. Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            self.login_as_employee()
        elif choice == '2':
            self.login_as_customer()
        elif choice == '3':
            sys.exit()
        else:
            print("Invalid choice. Please try again.")
            self.login_menu()

    def login_as_employee(self):
        pin = input("Enter employee PIN: ")
        if pin == self.pin:
            print("Employee login successful!")
            self.employee_menu()
        else:
            print("Invalid PIN. Please try again.")
            self.login_menu()

    def login_as_customer(self):
        bank.login_as_customer()

    def employee_menu(self):
        print("Employee Menu")
        print("1. Create Customer Account")
        print("2. Delete Customer Account")
        print("3. Create Transaction")
        print("4. List Customers")
        print("5. Log out")
        choice = input("Enter your choice: ")
        if choice == '1':
            bank.create_customer_account()
        elif choice == '2':
            bank.delete_customer_account()
        elif choice == '3':
            account_number = input("Enter the account number: ")
            account_type = input("Enter the account type (savings/current): ")
            bank.create_transaction(account_number, account_type)
        elif choice == '4':
            bank.list_customers()
        elif choice == '5':
            self.login_menu()
        else:
            print("Invalid choice. Please try again.")
            self.employee_menu()


class Customer:
    def __init__(self, first_name, last_name, email, pin):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.pin = pin
        self.account_number = None
        self.savings_balance = 0
        self.current_balance = 0

    def customer_menu(self, bank):
        os.system('cls')
        print(f"Welcome, {self.first_name} !")
        print("1. Check Balance")
        print("2. Perform Transaction")
        print("3. Log out")
        choice = input("Enter your choice: ")
        if choice == '1':
            account_type = input("Enter the account type (savings/current): ")
            bank.display_transactions(self.account_number, account_type)
        elif choice == '2':
            account_type = input("Enter the account type (savings/current): ")
            bank.create_transaction(self.account_number, account_type)
        elif choice == '3':
            bank.login_menu()
        else:
            print("Invalid choice. Please try again.")
            self.customer_menu(bank)

    def perform_transaction_menu(self, bank):
        os.system('cls')
        print("Select account type:")
        print("1. Savings Account")
        print("2. Current Account")
        account_choice = input("Enter your choice: ")
        if account_choice == '1':
            bank.perform_transaction(self, 'savings')
        elif account_choice == '2':
            bank.perform_transaction(self, 'current')
        else:
            print("Invalid choice. Please try again.")


class Bank:
    def __init__(self):
        self.employees_pin = 'A1234'
        self.customers = {}
        self.transactions_directory = 'transactions'
        self.customers_file = 'customers.txt'
        self.registered_accounts = []

        # Create transactions directory if it doesn't exist
        if not os.path.exists(self.transactions_directory):
            os.makedirs(self.transactions_directory)

        # Load existing customer accounts from file
        self.load_customer_accounts()

    def load_customer_accounts(self):
        if os.path.exists(self.customers_file):
            with open(self.customers_file, 'r') as file:
                lines = file.readlines()
                for line in lines:
                    account_data = line.strip().split(',')
                    account_number = account_data[0]
                    first_name = account_data[1]
                    last_name = account_data[2]
                    email = account_data[3]
                    pin = account_data[4]
                    savings_balance = float(account_data[5])
                    current_balance = float(account_data[6])

                    self.customers[account_number] = {
                        'first_name': first_name,
                        'last_name': last_name,
                        'email': email,
                        'pin': pin,
                        'savings_balance': savings_balance,
                        'current_balance': current_balance
                    }
    
    def update_customer_file(self):
        with open(self.customers_file, 'w') as file:
            for account_number, customer in self.customers.items():
                first_name = customer['first_name']
                last_name = customer['last_name']
                email = customer['email']
                pin = customer['pin']
                savings_balance = customer['savings_balance']
                current_balance = customer['current_balance']
                file.write(f"{account_number},{first_name},{last_name},{email},{pin},{savings_balance},{current_balance}\n")

    def create_transaction_file(self, account):
        file_name = f"{account.account_number}-{account.account_type.lower()}.txt"

        with open(file_name, "w") as file:
            file.write("Date\tAction\tAmount\tBalance\n")
            for transaction in account.transactions:
                file.write(f"{transaction['date']}\t{transaction['action']}\t{transaction['amount']}\t{transaction['balance']}\n")

    
    
    def save_transaction(self, account_number, account_type, transaction_type, amount, new_balance):
        file_path = os.path.join(self.transactions_directory, f"{account_number}-{account_type}.txt")
        with open(file_path, 'a') as file:
            date = datetime.datetime.now().strftime("%d-%m-%Y")
            transaction_record = f"{date}\t{transaction_type}\t{amount}\t{new_balance}\n"
            file.write(transaction_record)
            
    def login_menu(self):
        employee = Employee(self.employees_pin)
        employee.login_menu()

    def login_as_customer(self):
        first_name = input("Enter your first name: ")
        last_name = input("Enter your last name: ")
        account_number = input("Enter your account number: ")
        pin = input("Enter your PIN: ")
        customer_info = self.customers.get(account_number)
        if customer_info and customer_info['first_name'] == first_name and customer_info['last_name'] == last_name and customer_info['pin'] == pin:
            customer_info['account_number'] = account_number  # Add account_number to customer_info
            print("Customer login successful!")
            customer = Customer(first_name, last_name, customer_info['email'], pin)
            customer.account_number = account_number
            customer.savings_balance = customer_info['savings_balance']
            customer.current_balance = customer_info['current_balance']
            customer.customer_menu(self)
        else:
            print("Invalid customer credentials. Please try again.")
            self.login_as_customer()

    def create_customer_account(self):
        os.system('cls')
        print("=== Create a New Customer Account ===")
        first_name = input("Enter customer's first name: ")
        last_name = input("Enter customer's last name: ")
        email = input("Enter customer's email: ")
        account_number = self.generate_account_number(first_name, last_name)
        pin = self.generate_pin(first_name, last_name)
        print("Account Number:", account_number)
        print("PIN:", pin)
        self.customers[account_number] = {
            'first_name': first_name,
            'last_name': last_name,
            'email': email,
            'pin': pin,
            'savings_balance': 0,
            'current_balance': 0
        }
        print("Customer account created successfully!")
        self.registered_accounts.append(customer)
           
        self.update_customer_file()
        self.login_menu()

    def delete_customer_account(self):
        account_number = input("Enter customer's account number: ")
        if account_number in self.customers:
            customer = self.customers[account_number]
            if customer['savings_balance'] == 0 and customer['current_balance'] == 0:
                del self.customers[account_number]
                print("Customer account deleted successfully!")
            else:
                print("Cannot delete customer with non-zero balances.")
        else:
            print("Customer account not found.")
        self.update_customer_file()
        employee.employee_menu()

    
    def create_transaction(self, account_number, account_type):
        date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if account_number in self.customers:
            customer = self.customers[account_number]
            transaction_type = input("Enter transaction type (lodge/withdraw): ")
            amount = float(input("Enter amount: "))
            if account_type == 'savings':
                balance = customer['savings_balance']
            elif account_type == 'current':
                balance = customer['current_balance']
            else:
                print("Invalid account type. Please try again.")
                employee.login_menu()
                return

            if transaction_type == 'lodge':
                new_balance = balance + amount
            elif transaction_type == 'withdraw':
                if amount <= balance:
                    new_balance = balance - amount
                else:
                    print("Insufficient funds. Cannot withdraw.")
                    employee.login_menu()
                    return
            else:
                print("Invalid transaction type. Please try again.")
                employee.login_menu()
                return

            if account_type == 'savings':
                customer['savings_balance'] = new_balance
            elif account_type == 'current':
                customer['current_balance'] = new_balance

            self.save_transaction(account_number, account_type, transaction_type, amount, new_balance)
            self.update_customer_file()
            print("Transaction completed successfully!")
            print(f"New {account_type.capitalize()} Balance: {new_balance}")
            employee.login_menu()
        else:
            print("Invalid account number. Please try again.")
            employee.login_menu()


    def display_transactions(self, account_number, account_type):
        file_path = os.path.join(self.transactions_directory, f"{account_number}-{account_type}.txt")
        if os.path.exists(file_path):
            with open(file_path, 'r') as file:
                transactions = file.readlines()
                if len(transactions) > 0:
                    print("Transaction History:")
                    for transaction in transactions:
                        date, transaction_type, amount, balance = transaction.strip().split("\t")
                        print("Date:", date)
                        print("Transaction Type:", transaction_type)
                        print("Amount:", amount)
                        print("Balance:", balance)
                        print()
                else:
                    print("No transactions found for the specified account.")
            customer.customer_menu()
        else:
            print("No transactions found for the specified account.")

    def save_customers(self):
        with open(self.customers_file, 'w') as file:
            for customer in self.customers.values():
                line = f"{customer.first_name},{customer.last_name},{customer.email},{customer.pin},{customer.account_number},{customer.savings_balance},{customer.current_balance}\n"
                file.write(line)

    def list_customers(self):
        if self.customers:
            print("Customer List:")
            for account_number, customer in self.customers.items():
                print(f"Account Number: {account_number}")
                print(f"Customer Name: {customer['first_name']} {customer['last_name']}")
                print(f"Savings Balance: {customer['savings_balance']}")
                print(f"Current Balance: {customer['current_balance']}")
                print("---------------------------")
            employee.employee_menu()
        else:
            print("No customers found.")
            employee.employee_menu()

    def generate_pin(self, first_name, last_name):
        first_initial_position = ord(first_name[0].upper()) - ord('A') + 1
        second_initial_position = ord(last_name[0].upper()) - ord('A') + 1
        pin = f"{first_initial_position}{second_initial_position}"
        return pin

    def generate_account_number(self, first_name, last_name):
        initials = f"{first_name[0]}{last_name[0]}".lower()
        length_of_name = len(first_name) + len(last_name)
        first_initial_position = ord(first_name[0].upper()) - ord('A') + 1
        second_initial_position = ord(last_name[0].upper()) - ord('A') + 1
        pin = f"{first_initial_position}-{second_initial_position}"
        account_number = f"{initials}-{length_of_name}-{pin}"
        return account_number

    def create_transaction_file(self, filename):
        file_path = os.path.join(self.transactions_directory, filename)
        with open(file_path, 'w') as file:
            file.write("Date\t\tAction\t\tAmount\t\tBalance\n")

    def write_transaction(self, filename, action, amount, balance):
        file_path = os.path.join(self.transactions_directory, filename)
        with open(file_path, 'a') as file:
            date = datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            file.write(f"{date}\t{action}\t{amount}\t{balance}\n")


bank = Bank()
employee = Employee('A1234')
customer = Customer('', '', '', '')

bank.login_menu()

           

